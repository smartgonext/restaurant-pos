import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { Input } from '@/components/ui/Input';
import { Skeleton } from '@/components/ui/Skeleton';
import { Package, Plus, Check, Star, Edit, Trash2 } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';
import api from '@/lib/api';
import toast from 'react-hot-toast';

export default function Packages() {
  const [showAdd, setShowAdd] = useState(false);
  const [formData, setFormData] = useState({
    name: '', description: '', monthlyPrice: '', annualPrice: '', lifetimePrice: '',
    isRecommended: false, isDefault: false, trialDays: '14',
    modules: ['menu', 'orders', 'tables', 'pos', 'customers', 'staff', 'reports'],
  });

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['superadmin-packages'],
    queryFn: () => api.get('/superadmin/packages').then((r) => r.data.data),
  });

  const allModules = [
    'Menu', 'Orders', 'Tables', 'POS', 'Customers', 'Staff', 'Reports',
    'Inventory', 'Kitchen', 'Expenses', 'Cash Register', 'Reservations',
    'AI Insights', 'Loyalty', 'Delivery', 'Webhooks', 'WhatsApp', 'Kiosk',
    'Customer Display', 'Order Board', 'Area Management', 'Modifier Groups',
    'Branch Management', 'Role Management', 'Theme Setting', 'Export Reports',
    'Payment Integration', 'KOT System', 'QR Menu'
  ];

  const toggleModule = (mod: string) => {
    setFormData((prev) => ({
      ...prev,
      modules: prev.modules.includes(mod) ? prev.modules.filter((m) => m !== mod) : [...prev.modules, mod],
    }));
  };

  const handleCreate = async () => {
    try {
      await api.post('/superadmin/packages', {
        ...formData,
        monthlyPrice: formData.monthlyPrice ? Number(formData.monthlyPrice) : null,
        annualPrice: formData.annualPrice ? Number(formData.annualPrice) : null,
        lifetimePrice: formData.lifetimePrice ? Number(formData.lifetimePrice) : null,
        trialDays: Number(formData.trialDays),
      });
      toast.success('Package created!');
      setShowAdd(false);
      refetch();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to create');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this package?')) return;
    try {
      await api.delete(`/superadmin/packages/${id}`);
      toast.success('Package deleted');
      refetch();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed');
    }
  };

  if (isLoading) return <div className="grid grid-cols-1 md:grid-cols-3 gap-6">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-72" />)}</div>;

  return (
    <div className="space-y-6 animate-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Packages</h1>
          <p className="text-sm text-text-muted mt-1">Manage subscription packages</p>
        </div>
        <Button icon={<Plus className="w-4 h-4" />} onClick={() => setShowAdd(true)}>Create Package</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {data?.map((pkg: any) => (
          <Card key={pkg.id} className={`relative ${pkg.isRecommended ? 'ring-2 ring-blue-500 shadow-glow' : ''}`}>
            {pkg.isRecommended && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <Badge variant="info" className="flex items-center gap-1"><Star className="w-3 h-3" /> Recommended</Badge>
              </div>
            )}
            <div className="text-center mb-4">
              <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center mx-auto mb-3">
                <Package className="w-6 h-6 text-blue-400" />
              </div>
              <h3 className="text-xl font-bold text-text-primary">{pkg.name}</h3>
              <p className="text-sm text-text-muted mt-1">{pkg.description || 'No description'}</p>
            </div>

            <div className="text-center mb-4">
              {pkg.monthlyPrice && (
                <div>
                  <span className="text-3xl font-bold text-text-primary">{formatCurrency(Number(pkg.monthlyPrice))}</span>
                  <span className="text-text-muted text-sm">/mo</span>
                </div>
              )}
              {pkg.annualPrice && <p className="text-xs text-text-muted">{formatCurrency(Number(pkg.annualPrice))}/year</p>}
            </div>

            <div className="space-y-2 mb-4">
              {(pkg.modules as string[])?.slice(0, 6).map((mod: string) => (
                <div key={mod} className="flex items-center gap-2 text-sm text-text-secondary">
                  <Check className="w-3.5 h-3.5 text-success" />{mod.charAt(0).toUpperCase() + mod.slice(1)}
                </div>
              ))}
              {(pkg.modules as string[])?.length > 6 && (
                <p className="text-xs text-blue-400">+{(pkg.modules as string[]).length - 6} more modules</p>
              )}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-border">
              <span className="text-xs text-text-muted">{pkg._count?.subscriptions || 0} subscribers</span>
              <div className="flex gap-1">
                <button className="p-1.5 rounded hover:bg-bg-hover transition-colors"><Edit className="w-3.5 h-3.5 text-text-muted" /></button>
                <button onClick={() => handleDelete(pkg.id)} className="p-1.5 rounded hover:bg-danger/10 transition-colors"><Trash2 className="w-3.5 h-3.5 text-danger" /></button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Create Package" size="lg">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input label="Package Name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} placeholder="e.g. Professional" />
            <Input label="Trial Days" type="number" value={formData.trialDays} onChange={(e) => setFormData({ ...formData, trialDays: e.target.value })} />
          </div>
          <Input label="Description" value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} placeholder="Brief description" />
          <div className="grid grid-cols-3 gap-4">
            <Input label="Monthly Price" type="number" value={formData.monthlyPrice} onChange={(e) => setFormData({ ...formData, monthlyPrice: e.target.value })} placeholder="29" />
            <Input label="Annual Price" type="number" value={formData.annualPrice} onChange={(e) => setFormData({ ...formData, annualPrice: e.target.value })} placeholder="290" />
            <Input label="Lifetime Price" type="number" value={formData.lifetimePrice} onChange={(e) => setFormData({ ...formData, lifetimePrice: e.target.value })} placeholder="999" />
          </div>
          <div>
            <label className="text-sm font-medium text-text-secondary mb-2 block">Modules</label>
            <div className="flex flex-wrap gap-2">
              {allModules.map((mod) => (
                <button key={mod} onClick={() => toggleModule(mod)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${formData.modules.includes(mod) ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' : 'bg-bg-tertiary text-text-muted border border-border hover:bg-bg-hover'}`}>
                  {mod}
                </button>
              ))}
            </div>
          </div>
          <div className="flex justify-end gap-3 mt-6">
            <Button variant="secondary" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button onClick={handleCreate}>Create Package</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
