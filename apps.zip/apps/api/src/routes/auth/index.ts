import { FastifyInstance } from 'fastify';
import bcrypt from 'bcryptjs';
import { prisma } from '../../app.js';

export async function authRoutes(app: FastifyInstance) {
  // ── Restaurant Staff Login ──
  app.post('/login', async (request, reply) => {
    const { email, password } = request.body as { email: string; password: string };

    const staff = await prisma.staff.findFirst({
      where: { email, isActive: true },
      include: {
        restaurant: { select: { id: true, name: true, slug: true, status: true } },
        branch: { select: { id: true, name: true } },
      },
    });

    if (!staff) {
      return reply.status(401).send({ success: false, error: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(password, staff.password);
    if (!validPassword) {
      return reply.status(401).send({ success: false, error: 'Invalid credentials' });
    }

    if (staff.restaurant.status !== 'active') {
      return reply.status(403).send({ success: false, error: 'Restaurant is not active' });
    }

    // Update last login
    await prisma.staff.update({
      where: { id: staff.id },
      data: { lastLoginAt: new Date() },
    });

    const token = app.jwt.sign(
      {
        id: staff.id,
        role: staff.role,
        restaurantId: staff.restaurantId,
        branchId: staff.branchId,
        staffId: staff.id,
      },
      { expiresIn: process.env.JWT_EXPIRES_IN || '15m' }
    );

    const refreshToken = app.jwt.sign(
      { id: staff.id, type: 'refresh' },
      { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' }
    );

    return {
      success: true,
      data: {
        token,
        refreshToken,
        user: {
          id: staff.id,
          name: staff.name,
          email: staff.email,
          role: staff.role,
          avatar: staff.avatar,
          theme: staff.theme,
          language: staff.language,
          restaurant: staff.restaurant,
          branch: staff.branch,
        },
      },
    };
  });

  // ── SuperAdmin Login ──
  app.post('/superadmin/login', async (request, reply) => {
    const { email, password } = request.body as { email: string; password: string };

    const admin = await prisma.superAdminUser.findUnique({ where: { email } });
    if (!admin) {
      return reply.status(401).send({ success: false, error: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(password, admin.password);
    if (!validPassword) {
      return reply.status(401).send({ success: false, error: 'Invalid credentials' });
    }

    const token = app.jwt.sign(
      { id: admin.id, role: admin.role },
      { expiresIn: '1d' }
    );

    const refreshToken = app.jwt.sign(
      { id: admin.id, type: 'refresh' },
      { expiresIn: '7d' }
    );

    return {
      success: true,
      data: {
        token,
        refreshToken,
        user: {
          id: admin.id,
          name: admin.name,
          email: admin.email,
          role: admin.role,
          avatar: admin.avatar,
        },
      },
    };
  });

  // ── Refresh Token ──
  app.post('/refresh', async (request, reply) => {
    const { refreshToken } = request.body as { refreshToken: string };
    try {
      const decoded = app.jwt.verify(refreshToken) as { id: number; type: string };
      if (decoded.type !== 'refresh') {
        return reply.status(401).send({ success: false, error: 'Invalid token type' });
      }

      // Check if it's a staff or superadmin
      const staff = await prisma.staff.findUnique({ where: { id: decoded.id } });
      if (staff) {
        const token = app.jwt.sign(
          {
            id: staff.id,
            role: staff.role,
            restaurantId: staff.restaurantId,
            branchId: staff.branchId,
            staffId: staff.id,
          },
          { expiresIn: process.env.JWT_EXPIRES_IN || '15m' }
        );
        return { success: true, data: { token } };
      }

      const admin = await prisma.superAdminUser.findUnique({ where: { id: decoded.id } });
      if (admin) {
        const token = app.jwt.sign(
          { id: admin.id, role: admin.role },
          { expiresIn: '1d' }
        );
        return { success: true, data: { token } };
      }

      return reply.status(401).send({ success: false, error: 'User not found' });
    } catch {
      return reply.status(401).send({ success: false, error: 'Invalid refresh token' });
    }
  });

  // ── Logout ──
  app.post('/logout', async () => {
    return { success: true, message: 'Logged out successfully' };
  });
}
